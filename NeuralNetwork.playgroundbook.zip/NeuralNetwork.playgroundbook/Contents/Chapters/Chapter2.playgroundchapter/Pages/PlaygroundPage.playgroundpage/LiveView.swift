import PlaygroundSupport
import UIKit

PlaygroundPage.current.needsIndefiniteExecution = true
let vc = PlaygroundLiveViewController()
PlaygroundPage.current.liveView = vc
vc.page = 2
